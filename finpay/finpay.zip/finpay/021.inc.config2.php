

<?php 
 $conn= mysqli_connect("103.15.226.133","admin","trimindi173","halokick");
 //mysql_connect("103.15.226.133", "admin", "trimindi173") or die("Could not connect : " . mysql_error());
//mysql_select_db("021_dummy") or die("Could not select database");
?>