1. Read "195 Integration Guide_en.pdf"
2. This merchant simulator just work in online host with public domain, PHP server and SQL database. (Not work in localhost)
3. Open "195.inc.config.php" and setting with your condition
4. Create database MySQL with name "195_dummy"
5. Upload "195_dummy.sql" into database "195_dummy"
6. Run "index.php" with the URL in browser (Mozilla, Chrome, IE and Other Browser)