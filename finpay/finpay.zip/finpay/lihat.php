<?php


echo "string";

?>